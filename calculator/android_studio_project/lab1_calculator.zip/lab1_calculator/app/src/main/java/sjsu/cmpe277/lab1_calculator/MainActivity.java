package sjsu.cmpe277.lab1_calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.String;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

/* Reference:
   https://www.javahelps.com/2015/03/android-simple-calculator.html
*/
public class MainActivity extends AppCompatActivity {

    //Numbers
    private int[] num_keys= {
            R.id.btnZero, R.id.btnOne, R.id.btnTwo, R.id.btnThree,
            R.id.btnFour, R.id.btnFive, R.id.btnSix, R.id.btnSeven,
            R.id.btnEight, R.id.btnNine};

    // Operators
    private int[] op_keys= {
            R.id.btnPlus, R.id.btnMinus, R.id.btnMul, R.id.btnDiv,
            R.id.btnEquals};

    // TextView
    private TextView txtScreen;

    // Represent whether the lastly pressed key is numeric or not
    private boolean isLastPressedNum;

    // Represent that current state is in error or not
    private boolean isError;

    // If true, do not allow to add another DOT
    private boolean isLastPressedDot;

    // If true, do not allow to add another DOT
    private boolean isResult;

    private static final String TAG = "MyActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.txtScreen = findViewById(R.id.txtScreen);
        setHandlersForNumKeys();
        setHandlersForOpKeys();
    }

    private void setHandlersForNumKeys()
    {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                if (isError || isResult) {
                    txtScreen.setText(button.getText());
                    isError = false;
                    isResult = false;
                } else {
                    txtScreen.append(button.getText());
                }
                isLastPressedNum = true;
            }
        };
        for (int id : num_keys) {
            findViewById(id).setOnClickListener(listener);
        }
    }

    private void setHandlersForOpKeys() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLastPressedNum && !isError) {
                    Button button = (Button) v;
                    txtScreen.append(button.getText());
                    isLastPressedNum = false;
                    isLastPressedDot = false;    // Reset the DOT flag
                }
            }
        };
        // Assign the listener to all the operator buttons
        for (int id : op_keys) {
            findViewById(id).setOnClickListener(listener);
        }
        // Decimal point
        findViewById(R.id.btnDot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLastPressedNum && !isError && !isLastPressedDot) {
                    txtScreen.append(".");
                    isLastPressedNum = false;
                    isLastPressedDot = true;
                }
            }
        });
        // Clear button
        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtScreen.setText("");
                isLastPressedNum = false;
                isError = false;
                isLastPressedDot = false;
            }
        });

        // Equal button
        findViewById(R.id.btnEquals).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                compute();
            }
        });
    }

    private void compute() {
        if (isLastPressedNum && !isError) {
            String txt = txtScreen.getText().toString();
            Expression expression = new ExpressionBuilder(txt).build();
            try {
                double result = expression.evaluate();
                if((result * 10) % 10 == 0)
                    txtScreen.setText(Integer.toString((int)result));
                else
                    txtScreen.setText(Double.toString(result));
                isResult = true; // Result contains a dot
            } catch (ArithmeticException ex) {
                // Display an error message
                txtScreen.setText("Error");
                isError = true;
                isLastPressedNum = false;
            }
        }
    }
}
