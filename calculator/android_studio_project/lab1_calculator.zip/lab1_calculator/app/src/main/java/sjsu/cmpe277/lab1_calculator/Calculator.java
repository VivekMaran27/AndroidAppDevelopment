package sjsu.cmpe277.lab1_calculator;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Map;
import java.util.HashMap;
import android.util.Log;

public class Calculator {

    private static final String TAG = "Calculator";
    private Queue<String> postfix_q;
    private Stack<String> op_stack;
    private Stack<Integer> num_stack;
    private static final Map<String, Integer> myMap = new HashMap<>();
    static {
        myMap.put("(",2);
        myMap.put(")",2);
        myMap.put("*",1);
        myMap.put("/",1);
        myMap.put("+",0);
        myMap.put("-",0);
    }

    Calculator()
    {
        postfix_q = new LinkedList<>();
        op_stack = new Stack<>();
        num_stack = new Stack<>();
    }

    private void handleOperator(String token)
    {
        String op = new String();
        switch(token)
        {
            case "(":
            {
                System.out.println("Pushing: "+token);
                op_stack.push(token);
                break;
            }
            case ")":
            {
                while(!(op = op_stack.pop()).equals("("))
                {
                    System.out.println("Popped: "+op);
                    postfix_q.add(op);
                }
                break;
            }
            case "*":
            case "/":
            case "+":
            case "-":
            {
                if(op_stack.empty() || op_stack.peek()=="(")
                {
                    System.out.println("Pushing: "+token);
                    op_stack.push(token);
                }
                else if (myMap.get(token) > myMap.get(op_stack.peek()))
                {
                    System.out.println("Pushing: "+token);
                    op_stack.push(token);
                }
                else if (myMap.get(token) <= myMap.get(op_stack.peek()))
                {
                    System.out.println("Top of stack: "+ op_stack.peek());
                    while((!op_stack.peek().equals("(")) &&
                          (myMap.get(token) <= myMap.get(op_stack.peek())))
                    {
                        op = op_stack.pop();
                        System.out.println("Popped: "+op);
                        postfix_q.add(op);
                        if(op_stack.empty())
                            break;
                    }
                    System.out.println("Pushing: "+token);
                    op_stack.push(token);
                }
                break;
            }
            default:
                break;
        }
    }

    private int evaluate()
    {
        String ele;
        Integer ele_int;

        while(!postfix_q.isEmpty())
        {
           ele = postfix_q.remove();
           System.out.println("Removing element: "+ele);
           try
           {
               ele_int = Integer.parseInt(ele);
               num_stack.push(ele_int);
           }
           catch (Exception e)
           {
               System.out.println(e.getMessage());
               Integer right_op = num_stack.pop();
               Integer left_op = num_stack.pop();
               switch(ele) {
                   case "*":
                   {
                       num_stack.push(left_op*right_op);
                       break;
                   }
                   case "/":
                   {
                       num_stack.push(left_op/right_op);
                       break;
                   }
                   case "+": {
                       num_stack.push(left_op + right_op);
                       break;
                   }
                   case "-": {
                       num_stack.push(left_op - right_op);
                       break;
                   }
                   default:
                       break;
               }
           }
        }
        return (num_stack.pop());
    }

    public String infixToPostFix(String expr)
    {
        char token;
        String number = new String();
        String postfix_expr = new  String();
        for(int i =0; i<expr.length(); ++i) {
            token = expr.charAt(i);
            if(Character.isDigit(token)) {
                number += "" + token;
            }
            else if("+-*/()".indexOf(token) != -1){
                System.out.println("Adding number "+number);
                if(!number.isEmpty())
                {
                    postfix_q.add(number);
                    number = "";
                }
                handleOperator(""+token);
            }
        }
        if(!number.isEmpty())
        {
            System.out.println("Adding number "+number);
            postfix_q.add(number);
        }
        while(!op_stack.empty())
            postfix_q.add(op_stack.pop());

        op_stack.clear();
        return postfix_expr;
    }

    public int evalExpression(String expr)
    {
        int result = 0;
        infixToPostFix(expr);
        result = evaluate();
        Log.d(TAG, "Result:" +" " + result);
        return result;
    }

}
